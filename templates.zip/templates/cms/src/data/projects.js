// Project data — populate via CMS admin panel
export const projects = [];
