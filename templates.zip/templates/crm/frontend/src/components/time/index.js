export { default as TimeClock, TimeClockCompact } from './TimeClock';
